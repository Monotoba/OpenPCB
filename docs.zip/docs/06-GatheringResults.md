# Gathering Results

- Functional: formats import; CAM correctness at 0.01 mm tolerance; 4-device streaming stable.
- Quality: isolation accuracy ±0.02 mm; drill hit ≥99.5%; time estimate error <10%.
- Performance: 1M segments ≥45 FPS; 100×100 mm board CAM < 10s.
- Stability: MTBC > 20h; autosave ≤ 5s.
