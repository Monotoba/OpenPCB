# Background

Hobbyists and small fabrication shops often juggle multiple tools to take a PCB from design files to finished boards. This app unifies CAM + sender + job management with Python 3.10+ and PySide6.
