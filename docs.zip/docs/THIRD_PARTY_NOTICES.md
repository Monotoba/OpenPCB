# THIRD_PARTY_NOTICES

- PySide6 — LGPLv3
- Shapely — BSD-3-Clause
- svgpathtools — MIT
- Pillow — HPND/PIL
- scikit-image — BSD-3-Clause
- pyserial — BSD-style
- gerbonara — Apache-2.0
- vpype — MIT

Include exact versions and URLs in release artifacts.
