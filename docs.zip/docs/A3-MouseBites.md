# Mouse-Bite Panelization

- Parameters: tab width/thickness, hole diameter/pitch, inset, silk/copper clearance, min edge clearance.
- Placement: shared edge detection, spacing, anchor nudging, hole array, DRC, toolpath impacts.
- Strength heuristic and pseudocode included.
