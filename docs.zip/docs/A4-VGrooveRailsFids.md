# V-Groove & Panel Rails/Fiducials

- V-groove parameters, kerf formula, path extraction, toolpath emission, sequencing.
- Rails: rail width, panel clear, connecting tabs, fiducials placement, tooling holes.
- Pseudocode and DRC guidance.
